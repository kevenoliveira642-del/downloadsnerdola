
import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Download, 
  Plus, 
  Tag, 
  Calendar, 
  HardDrive, 
  Info,
  X,
  PlusCircle,
  Loader2,
  ChevronRight,
  Monitor
} from 'lucide-react';
import { Category, DownloadPost } from './types';
import { INITIAL_POSTS } from './constants';
import { generatePostContent } from './services/geminiService';

const App: React.FC = () => {
  const [posts, setPosts] = useState<DownloadPost[]>(INITIAL_POSTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Todos'>('Todos');
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // New Post Form State
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostCategory, setNewPostCategory] = useState<Category>(Category.Software);

  const filteredPosts = useMemo(() => {
    return posts.filter(post => {
      const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          post.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'Todos' || post.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [posts, searchQuery, selectedCategory]);

  const handleAddPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle) return;

    setIsGenerating(true);
    try {
      const geminiData = await generatePostContent(newPostTitle, newPostCategory);
      
      const newPost: DownloadPost = {
        id: Math.random().toString(36).substr(2, 9),
        title: newPostTitle,
        description: geminiData.description,
        category: newPostCategory,
        imageUrl: `https://picsum.photos/seed/${newPostTitle}/800/450`,
        downloadUrl: '#',
        fileSize: `${Math.floor(Math.random() * 500) + 10} MB`,
        version: '1.0.0',
        createdAt: Date.now(),
      };

      setPosts([newPost, ...posts]);
      setNewPostTitle('');
      setShowAdminModal(false);
    } catch (error) {
      console.error("Erro ao gerar post:", error);
      alert("Houve um erro ao gerar o conteúdo com IA. Tente novamente.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 px-4 md:px-8 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Download className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">
              DownloadHub
            </h1>
          </div>

          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text"
              placeholder="Buscar downloads..."
              className="w-full bg-slate-800 border border-slate-700 rounded-full py-2 pl-10 pr-4 text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <button 
            onClick={() => setShowAdminModal(true)}
            className="hidden md:flex items-center gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 px-4 py-2 rounded-lg transition-colors text-sm font-medium"
          >
            <PlusCircle className="w-4 h-4" />
            Novo Post
          </button>
        </div>
      </header>

      {/* Hero / Featured Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Sidebar */}
          <aside className="w-full md:w-64 space-y-6">
            <div>
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Tag className="w-4 h-4" /> Categorias
              </h2>
              <div className="flex flex-wrap md:flex-col gap-2">
                {['Todos', ...Object.values(Category)].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat as any)}
                    className={`px-4 py-2 rounded-lg text-sm text-left transition-all ${
                      selectedCategory === cat 
                      ? 'bg-indigo-600 text-white font-medium shadow-lg shadow-indigo-600/20' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="hidden md:block p-4 rounded-xl bg-gradient-to-br from-indigo-900/40 to-slate-800 border border-indigo-500/20">
              <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                <Monitor className="w-4 h-4 text-indigo-400" /> IA Powered
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Nossas descrições e metadados são otimizados usando Gemini AI para garantir que você tenha as melhores informações.
              </p>
            </div>
          </aside>

          {/* Posts Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Downloads Disponíveis
                <span className="text-sm font-normal text-slate-500 bg-slate-800 px-2 py-0.5 rounded-full">
                  {filteredPosts.length}
                </span>
              </h2>
            </div>

            {filteredPosts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPosts.map((post) => (
                  <div key={post.id} className="group flex flex-col bg-slate-800/40 border border-slate-700/50 rounded-2xl overflow-hidden hover:border-indigo-500/50 transition-all hover:shadow-2xl hover:shadow-indigo-500/10">
                    <div className="relative h-48 overflow-hidden">
                      <img 
                        src={post.imageUrl} 
                        alt={post.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                      />
                      <div className="absolute top-3 left-3">
                        <span className="bg-slate-900/80 backdrop-blur-md text-indigo-400 text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <h3 className="text-lg font-bold text-white mb-2 line-clamp-1">{post.title}</h3>
                      <p className="text-sm text-slate-400 mb-4 line-clamp-2 flex-1">
                        {post.description}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-3 mb-5 py-3 border-y border-slate-700/50">
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <HardDrive className="w-3.5 h-3.5" />
                          <span>{post.fileSize}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <Info className="w-3.5 h-3.5" />
                          <span>v{post.version}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(post.createdAt).toLocaleDateString()}
                        </span>
                        <a 
                          href={post.downloadUrl}
                          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-lg shadow-indigo-600/20"
                        >
                          <Download className="w-4 h-4" />
                          Baixar
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-center">
                <div className="bg-slate-800 p-6 rounded-full mb-4">
                  <Search className="w-12 h-12 text-slate-600" />
                </div>
                <h3 className="text-xl font-medium text-slate-300">Nenhum resultado encontrado</h3>
                <p className="text-slate-500 mt-2">Tente ajustar seus filtros ou busca.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Download className="w-5 h-5 text-indigo-500" />
              <span className="text-lg font-bold text-white">DownloadHub</span>
            </div>
            <p className="text-slate-500 text-sm max-w-sm">
              Sua plataforma centralizada para descobrir e baixar as melhores ferramentas digitais e recursos.
            </p>
          </div>
          <div className="flex gap-8">
            <div className="flex flex-col gap-2">
              <span className="text-white text-sm font-semibold">Links Rápidos</span>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">Privacidade</a>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">Termos de Uso</a>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">DMCA</a>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-white text-sm font-semibold">Comunidade</span>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">Discord</a>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">X / Twitter</a>
              <a href="#" className="text-slate-500 hover:text-indigo-400 text-sm">Github</a>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-slate-800 text-center text-slate-600 text-xs">
          © {new Date().getFullYear()} DownloadHub. Todos os direitos reservados. Feito com ❤️ e Inteligência Artificial.
        </div>
      </footer>

      {/* Mobile Floating Action Button */}
      <button 
        onClick={() => setShowAdminModal(true)}
        className="md:hidden fixed bottom-6 right-6 w-14 h-14 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full flex items-center justify-center shadow-xl shadow-indigo-600/40 z-50 transition-all active:scale-90"
      >
        <Plus className="w-6 h-6" />
      </button>

      {/* Admin Modal (Simulated Add Post) */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={() => !isGenerating && setShowAdminModal(false)} />
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">Novo Download</h2>
              {!isGenerating && (
                <button onClick={() => setShowAdminModal(false)} className="text-slate-400 hover:text-white p-1">
                  <X className="w-6 h-6" />
                </button>
              )}
            </div>

            <form onSubmit={handleAddPost} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Nome do Software / Recurso</label>
                <input 
                  autoFocus
                  required
                  type="text"
                  placeholder="Ex: Photoshop 2024, Unreal Engine Asset, etc."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  value={newPostTitle}
                  onChange={(e) => setNewPostTitle(e.target.value)}
                  disabled={isGenerating}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-2">Categoria</label>
                <select 
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/50 appearance-none"
                  value={newPostCategory}
                  onChange={(e) => setNewPostCategory(e.target.value as Category)}
                  disabled={isGenerating}
                >
                  {Object.values(Category).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div className="p-4 rounded-xl bg-indigo-900/20 border border-indigo-500/20">
                <p className="text-xs text-indigo-300 leading-relaxed flex gap-2">
                  <Info className="w-4 h-4 shrink-0" />
                  Ao clicar em publicar, o Gemini AI criará automaticamente uma descrição profissional e gerará metadados otimizados para seu download.
                </p>
              </div>

              <button 
                type="submit"
                disabled={isGenerating || !newPostTitle}
                className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl font-bold transition-all ${
                  isGenerating || !newPostTitle
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20'
                }`}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Gerando conteúdo com IA...
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    Publicar Download
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
