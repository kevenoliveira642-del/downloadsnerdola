
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiResponse } from "../types";

const API_KEY = process.env.API_KEY || '';

export const generatePostContent = async (title: string, category: string): Promise<GeminiResponse> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Gere uma descrição atraente e uma lista de 4 recursos para um post de download chamado "${title}" na categoria "${category}". O tom deve ser profissional e focado em tecnologia.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          description: {
            type: Type.STRING,
            description: "Uma breve descrição (máximo 150 caracteres) do software ou recurso.",
          },
          features: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Lista de 4 principais características.",
          },
        },
        required: ["description", "features"],
      },
    },
  });

  return JSON.parse(response.text) as GeminiResponse;
};
