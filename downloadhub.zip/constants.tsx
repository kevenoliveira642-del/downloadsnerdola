
import React from 'react';
import { DownloadPost, Category } from './types';

export const INITIAL_POSTS: DownloadPost[] = [
  {
    id: '1',
    title: 'Visual Studio Code v1.85',
    description: 'O editor de código fonte mais popular, otimizado para performance e produtividade.',
    category: Category.Software,
    imageUrl: 'https://picsum.photos/seed/vscode/800/450',
    downloadUrl: '#',
    fileSize: '89 MB',
    version: '1.85.0',
    createdAt: Date.now() - 86400000,
  },
  {
    id: '2',
    title: 'Cyberpunk Asset Pack',
    description: 'Conjunto completo de texturas e modelos 3D para jogos com temática futurista.',
    category: Category.Assets,
    imageUrl: 'https://picsum.photos/seed/cyber/800/450',
    downloadUrl: '#',
    fileSize: '1.2 GB',
    version: '2.1',
    createdAt: Date.now() - 172800000,
  },
  {
    id: '3',
    title: 'Open Shot Video Editor',
    description: 'Editor de vídeo open-source poderoso e fácil de usar para criadores de conteúdo.',
    category: Category.Tools,
    imageUrl: 'https://picsum.photos/seed/video/800/450',
    downloadUrl: '#',
    fileSize: '150 MB',
    version: '3.0.0',
    createdAt: Date.now() - 259200000,
  }
];
