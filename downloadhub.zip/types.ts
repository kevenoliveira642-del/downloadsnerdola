
export enum Category {
  Software = 'Software',
  Games = 'Jogos',
  Assets = 'Assets',
  Tools = 'Ferramentas',
  Templates = 'Templates'
}

export interface DownloadPost {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  category: Category;
  imageUrl: string;
  downloadUrl: string;
  fileSize: string;
  version: string;
  createdAt: number;
}

export interface GeminiResponse {
  description: string;
  features: string[];
}
